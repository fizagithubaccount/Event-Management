package com.edubridge.app1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SringBootRestApiProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SringBootRestApiProject1Application.class, args);
	}

}
